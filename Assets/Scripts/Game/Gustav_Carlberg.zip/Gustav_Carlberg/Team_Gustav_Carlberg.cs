using System;
using Game;
using Graphs;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Game.Gustav_Carlberg;
using UnityEngine;

namespace Gustav_Carlberg {
	public class Team_Gustav_Carlberg : Team {
		[SerializeField] private Color m_myFancyColor;


		#region Constants

		private const float TooFarApartThreshold = 12f;
		private const float FleeDistance = 5.0f;
		private const float LowHealthThreshold = 2;
		private const float TeamProximityThreshold = 800.0f;

		#endregion

		private float[] m_firePowerSteps = new[] { -0.2f, -0.4f, -0.6f, -0.8f, -1.0f };

		private Data_Gustav_Carlberg m_data = new();
		private List<Battlefield.Node> m_covers = new();
		private Battlefield.Node BestNode = null;

		private float SquareMagnitude = 0;
		
		List<Battlefield.Node> sortedNodes = new List<Battlefield.Node>();
		List<Battlefield.Node> closestNodes = new List<Battlefield.Node>();

		public List<Unit_Gustav_Carlberg> m_myUnits { get; private set; } // collection of all friendly team units
		public Dictionary<Vector2Int, Battlefield.Node> m_nodeLookup = new Dictionary<Vector2Int, Battlefield.Node>();

		private static readonly Vector2Int[] sm_directions = new Vector2Int[] {
			new Vector2Int(1, 0), new Vector2Int(-1, 0), new Vector2Int(0, 1), new Vector2Int(0, -1),
			new Vector2Int(-1, -1), new Vector2Int(1, 1), new Vector2Int(1, -1), new Vector2Int(-1, 1)
		};

		private InfluenceMap_Gustav_Carlberg m_infMap; // to be continued

		private Vector2Int[][] m_teamFormations = new Vector2Int[][] {
			// formations, Not used
			new Vector2Int[] {
				new Vector2Int(0, 0),
				new Vector2Int(0, 0)
			},
			new Vector2Int[] {
				new Vector2Int(0, 0),
				new Vector2Int(0, 0),
				new Vector2Int(0, 0),
			},
			new Vector2Int[] {
				new Vector2Int(0, 0),
				new Vector2Int(0, 0),
				new Vector2Int(0, 0),
				new Vector2Int(0, 0),
			},
			new Vector2Int[] {
				new Vector2Int(-2, 0),
				new Vector2Int(-1, 0),
				new Vector2Int(0, 0),
				new Vector2Int(0, 1),
				new Vector2Int(0, -1)
			}
		};

		#region Properties

		public override Color Color => m_myFancyColor;

		public Vector2Int GetFormationPos(int teamCount, int siblingIndex) => teamCount > 2
			? m_teamFormations[teamCount - 2][siblingIndex]
			: new Vector2Int(0, 0);

		private Vector3 FleeVector => (AverageEnemyTeamPos - AverageTeamPos());

		private Vector3 AverageEnemyTeamPos => EnemyTeam.Units.Aggregate(new Vector3(0, 0, 0),
			(compareVector, unit) => compareVector + unit.transform.position / this.EnemyTeam.Units.Count());

		#endregion

		//average team position
		public Vector3 AverageTeamPos() {
			Vector3 calculatedVector = Vector3.zero;
			int count = 0;
			foreach (var unit in m_myUnits) {
				if (unit == null) continue;

				count++;
				calculatedVector += unit.transform.position;
			}

			return calculatedVector / count;
		}

		IEnumerator UpdateValuesMagnitude() {
			while (true) {
				SquareMagnitude = (AverageEnemyTeamPos - AverageTeamPos()).sqrMagnitude;
				yield return null;
				m_data.CalculateInfluence(m_myUnits.Cast<Unit>().ToList(), EnemyTeam.Units.ToList(), Battlefield.Instance.Nodes)
					.CalculateFirePower(EnemyTeam.Units.ToList(), Battlefield.Instance.Nodes);
				yield return null;
				m_covers = m_data.CalculateCover(EnemyTeam.Units.ToList(), Battlefield.Instance.Nodes);
				yield return null;
			}

			yield return null;
		}

		protected override void Start() {
			Time.timeScale = 1f;
			base.Start();
			m_myUnits = GetComponentsInChildren<Unit_Gustav_Carlberg>().ToList();

			int iterator = 0;
			foreach (var node in Battlefield.Instance.Nodes) {
				iterator++;
				if (node is Battlefield.Node currNode) {
					m_nodeLookup.Add(currNode.Position, currNode);
				}
			}

			

			//m_covers = m_data.CalculateCover(EnemyTeam.Units.ToList(), Battlefield.Instance.Nodes);


			// foreach (var value in m_nodeLookup.Values) {
			// 	if (m_data.GetNodeValue(value, out DataWrapper wrapper)) {
			// 		if (wrapper.EnemyFirePower != 0) {
			// 			// Debug.Log("Firepower:" +
			// 			//           wrapper.EnemyFirePower +
			// 			//           ", " +
			// 			//           "Cover:" +
			// 			//           wrapper.Cover +
			// 			//           ", " +
			// 			//           "Influence:" +
			// 			//           wrapper.Influence);
			// 		}
			// 	}
			// }

			//Battlefield.Node BestNode = null;
			

			// foreach (var VARIABLE in sortedNodes) {
			// 	Debug.Log(VARIABLE);
			// }

			StartCoroutine(UpdateValuesMagnitude());
			StartCoroutine(UpdateBestNode());
		}

		private Battlefield.Node FindOptimalNode() {
			
			sortedNodes = new List<Battlefield.Node>();
			for (int i = 0; i < m_firePowerSteps.Length; i++) {
				foreach (var value in m_nodeLookup.Values) {
					if (m_data.GetNodeValue(value, out DataWrapper wrapper)) {
						if (m_firePowerSteps != null && Equals(wrapper.EnemyFirePower, m_firePowerSteps[i])) {
							if (!sortedNodes.Contains(value) && (value is not Game.Node_Mud)) {
								sortedNodes.Add(value);
							}
						}
					}
				}

				if (sortedNodes.Count() > 50) {
					break;
				}
			}

			// 10 closest
			List<Battlefield.Node> sortedByDistanceNodes =
				sortedNodes.OrderBy(x => Vector3.Distance(x.WorldPosition, AverageTeamPos())).ToList();
			closestNodes = new List<Battlefield.Node>();
			for (int i = 0; i < sortedByDistanceNodes.Count; i++) {
				closestNodes.Add(sortedByDistanceNodes[i]);
				if (closestNodes.Count >= 10) {
					break;
				}
			}


			Battlefield.Node bestNode = null;
			float highestValue = float.MinValue;
			foreach (var closestNode in closestNodes) {
				if (m_data.GetEntry(closestNode).Influence is float currValue) {
					if (bestNode == null || currValue > highestValue) {
						bestNode = closestNode;
						highestValue = currValue;
					}
				}
			}
			// foreach (var  in closestNodes) {
			// }
			// with lowest influence

				
			return bestNode;
		}

		private IEnumerator UpdateBestNode() {
			while (true) {
				m_data.CalculateFirePower(EnemyTeam.Units.ToList(), Battlefield.Instance.Nodes);
				yield return null;
				float lowestValue = float.MinValue;
				foreach (var value in m_nodeLookup.Values) {
					if (m_data.GetEntry(value).EnemyFirePower is { } floatValue) {
						if (floatValue < 0) {
							if (BestNode is null || floatValue > lowestValue) {
								BestNode = value;
								lowestValue = floatValue;
							}
						}
					}
				}

				yield return null;
			}
		}
		
		public new GraphUtils.Path GetShortestPath(Battlefield.Node start, Battlefield.Node goal) {
			if (start == null ||
			    goal == null ||
			    start == goal ||
			    Battlefield.Instance == null) {
				return null;
			}

			// initialize pathfinding
			foreach (Battlefield.Node node in Battlefield.Instance.Nodes) {
				node?.ResetPathfinding();
			}

			// add start node
			start.m_fDistance = 0.0f;
			start.m_fRemainingDistance = Battlefield.Instance.Heuristic(goal, start);
			List<Battlefield.Node> open = new List<Battlefield.Node>();
			HashSet<Battlefield.Node> closed = new HashSet<Battlefield.Node>();
			open.Add(start);

			// search
			while (open.Count > 0) {
				// get next node (the one with the least remaining distance)
				Battlefield.Node current = open[0];
				for (int i = 1; i < open.Count; ++i) {
					if (open[i].m_fRemainingDistance < current.m_fRemainingDistance) {
						current = open[i];
					}
				}

				open.Remove(current);
				closed.Add(current);

				// found goal?
				if (current == goal) {
					// construct path
					GraphUtils.Path path = new GraphUtils.Path();
					while (current != null) {
						path.Add(current.m_parentLink);
						current = current != null && current.m_parentLink != null ? current.m_parentLink.Source : null;
					}

					path.RemoveAll(l => l == null); // HACK: check if path contains null links
					path.Reverse();
					return path;
				}
				else {
					foreach (Battlefield.Link link in current.Links) {
						if (link.Target is Battlefield.Node target) {
							if (!closed.Contains(target) &&
							    target.Unit == null) {
								if (m_data.GetEntry(target).Cover is { } coverValued) {
									float newDistance = current.m_fDistance +
									                    Vector3.Distance(current.WorldPosition, target.WorldPosition) +
									                    (target.AdditionalCost);
									float newRemainingDistance =
										newDistance + Battlefield.Instance.Heuristic(target, start);

									if (open.Contains(target)) {
										if (newRemainingDistance < target.m_fRemainingDistance) {
											// re-parent neighbor node
											target.m_fRemainingDistance = newRemainingDistance;
											target.m_fDistance = newDistance;
											target.m_parentLink = link;
										}
									}
									else {
										// add target to openlist
										target.m_fRemainingDistance = newRemainingDistance;
										target.m_fDistance = newDistance;
										target.m_parentLink = link;
										open.Add(target);
									}
								}
							}
						}
					}
				}
			}

			return null;
		}

		bool TooFarApart() {
			float combinedMagnitude = 0;
			foreach (var unit in m_myUnits) {
				if (unit == null) continue;

				Vector3 targetVector = AverageTeamPos() - unit.transform.position;
				combinedMagnitude += Vector3.Magnitude(targetVector);
			}

			if (combinedMagnitude > TooFarApartThreshold) {
				return true;
			}

			return false;
		}

		public Battlefield.Node FindBestUnOccupiedNode(Battlefield.Node targetNode) {
			// add node
			Battlefield.Node bestNode = targetNode;
			if (targetNode != null && targetNode.Unit != null) {
				foreach (var direction in sm_directions) {
					Vector2Int targetPos = direction + targetNode.Position;
					if (m_nodeLookup.ContainsKey(targetPos) && m_nodeLookup[targetPos].Unit == null) {
						bestNode = m_nodeLookup[targetPos];
					}
				}
			}

			return bestNode;
		}

		private Battlefield.Node FindNearbyCover(Battlefield.Node node) {
			var nearbyNodes = GraphUtils.GetNodesWithinDistance(Battlefield.Instance, node, 6);
			Battlefield.Node bestNode = null;
			foreach (var nearbyNode in nearbyNodes) {
				if (bestNode == null || m_data.GetEntry(nearbyNode).Cover > m_data.GetEntry(bestNode).Cover) {
					bestNode = nearbyNode;
				}
			}

			return bestNode;
		}

		private void Update() {
			foreach (var unit in m_myUnits) {
				if (unit == null) continue;

				if (unit.EnemiesInRange.Any() && EnemyTeam.Units.Count() <= m_myUnits.Count - 3) {
					var sortedList = unit.EnemiesInRange
						.OrderBy(x => Vector3.Distance(x.transform.position, unit.transform.position)).ToList();
					Battlefield.Node moveNode = FindBestUnOccupiedNode(GraphUtils.GetClosestNode<Battlefield.Node>(
						Battlefield.Instance,
						sortedList[0].transform.position));
					if (unit.TargetNode != moveNode) {
						unit.TargetNode = moveNode;
					}
				}
				else if (unit.EnemiesInRange.Any() &&
				    m_data.GetEntry(unit.CurrentNode).Cover > 0.6f && 
				    m_covers.Contains(unit.CurrentNode)) {
					unit.TargetNode = null;
				}
				else if (unit.EnemiesInRange.Any() && m_data.GetEntry(unit.CurrentNode).Cover < 0.6f) {
					unit.TargetNode = FindNearbyCover(FindBestUnOccupiedNode(FindOptimalNode()));
				}
				else if (!unit.m_fleeing) {
					Battlefield.Node moveNode = FindBestUnOccupiedNode(FindOptimalNode());
					if (unit.TargetNode != moveNode) {
						unit.TargetNode = moveNode;
					}
				}
				
				
				if (unit.m_fleeing) {
					unit.m_fleeTimer += Time.deltaTime;
				}

				if (unit.m_fleeTimer >= unit.m_fleeDuration) {
					unit.m_fleeing = false;
					unit.m_hasFled = true;
				}
			}
		}
	}
}