using System;
using AI;
using Game;
using Graphs;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.PlayerLoop;
using UnityEngine.Serialization;
using Random = UnityEngine.Random;

namespace Gustav_Carlberg {
	[System.Serializable] public class Unit_Gustav_Carlberg : Unit {


		#region Properties

		public Team_Gustav_Carlberg Team => base.Team as Team_Gustav_Carlberg;

		#endregion

		private Unit_Gustav_Carlberg m_teamCaptain = null;

		private Brain m_brain;

		public bool m_fleeing;
		public bool m_hasFled;

		public float m_fleeTimer = 0;
		public float m_fleeDuration = 1f;

		public Unit_Gustav_Carlberg Captain;

		protected override void Start() {
			base.Start();
			m_brain = GetComponent<Brain>();
			
			// List<Unit_Gustav_Carlberg> tempTeammates = new List<Unit_Gustav_Carlberg>();
			// foreach (var unit in Team.m_myUnits) {
			// 	if (unit != this) {
			// 		tempTeammates.Add(unit);
			// 	}
			// }

			//left for later

			// if (this.name != "Capn Crunch") {
			// 	foreach (var unit in m_brain.Tree.Blackboard.GetValue("TeamMates", new List<Unit_Gustav_Carlberg>())) {
			// 		if (unit.name == "Capn Crunch") {
			// 			Captain = unit;
			// 			m_brain.Tree.Blackboard.SetValue("Captain", unit);
			// 		}
			// 	}
			// }
			
			m_brain.Tree.Blackboard.SetValue("HealthThreshold", 3);
		}

		protected override void Update() {
			base.Update();
		
			if (Health > 0) {
				m_brain.Tree.Blackboard.SetValue("CurrentHealth", Health);
			}
		}

		protected override Unit SelectTarget(List<Unit> enemiesInRange) {
			// focus fire
			Unit lowestHealthUnit = null;
			float lowestHealth = float.MaxValue;
			foreach (var enemy in enemiesInRange) {
				if (enemy.Health < lowestHealth) {
					lowestHealth = enemy.Health;
					lowestHealthUnit = enemy;
				}
			}
			return lowestHealthUnit;
		}

		protected override GraphUtils.Path GetPathToTarget() {
			return Team.GetShortestPath(CurrentNode, TargetNode);
		}
	}
}