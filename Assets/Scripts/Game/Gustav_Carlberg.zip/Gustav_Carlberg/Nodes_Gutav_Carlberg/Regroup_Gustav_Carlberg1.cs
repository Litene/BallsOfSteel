using System.Collections;
using System.Collections.Generic;
using AI.Nodes;
using UnityEngine;

public class Regroup_Gustav_Carlberg : ActionNode {

	protected override void OnStart() {
		// if (expr) {
		// 	
		// }
	}

	protected override void OnStop() {
	}

	protected override State OnUpdate() {
		return State.Running;
	}
}