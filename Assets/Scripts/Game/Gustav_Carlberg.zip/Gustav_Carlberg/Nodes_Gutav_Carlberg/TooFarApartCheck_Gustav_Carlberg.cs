using System.Collections;
using System.Collections.Generic;
using AI.Nodes;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class TooFarApartCheck_Gustav_Carlberg : DecoratorNode {

	public bool m_bCheckEveryFrame;
	
	// Start is called before the first frame update
	void Start() {
	}

	// Update is called once per frame
	void Update() {
	}
	
	//Todo: floodfil decorator
	
}